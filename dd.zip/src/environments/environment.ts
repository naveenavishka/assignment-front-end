export const environment = {
  production: false,
 // apiAuth: 'http://10.11.5.69/auth.wms/token',
 // apiUrl: 'http://10.11.5.69/alert.api',
 
 // apiLoginUrl: 'http://10.11.5.69/oras.api'

  apiAuth: 'https://alert.hayleysAdvantis.com/auth.wms/token',
  // apiUrl: 'http://localhost:30235',
  apiLoginUrl: 'https://alert.hayleysAdvantis.com/api.logix.oras.api',

  //LiveAPIUrl
  //apiUrl: 'https://alert.hayleysadvantis.com/alert.api' //'https://corebrainwm.com/alert.api',

  // TestAPIURL
  //  apiUrl: 'http://localhost:30235',
   apiUrl: 'https://alert.hayleysadvantis.com/alert.api',
};
