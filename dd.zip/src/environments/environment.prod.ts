export const environment = {
  production: true,
  // apiAuth: 'https://Alert.HayleysAdvantis.com/Corebrain/auth.wms/token',
  // apiUrl: 'https://Alert.HayleysAdvantis.com/alert.api',
  // apiLoginUrl: 'https://Alert.HayleysAdvantis.com/oras.api'

  // apiAuth: 'http://10.11.5.69/auth.wms/token',
  // apiUrl: 'https://Alert.HayleysAdvantis.com/alert.api',
  // apiLoginUrl: 'http://10.11.5.69/oras.api'

  apiAuth: 'https://alert.hayleysAdvantis.com/auth.wms/token',
  apiUrl: 'https://alert.hayleysAdvantis.com/alert.api',
  apiLoginUrl: 'https://alert.hayleysAdvantis.com/api.logix.oras.api'
};
