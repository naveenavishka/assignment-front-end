import { Injectable } from '@angular/core';

@Injectable({
    providedIn:"root"
})
export class ConfData {
    screenWidth: any;
    screenHeight: any;
}
