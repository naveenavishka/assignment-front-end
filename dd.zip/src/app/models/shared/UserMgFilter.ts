export class UserMgFilter {
    varClusterCode: string;
    varSBUCode: string;
    varSIteCode: string;
    varUserStatus: string;
    varUserCode: string;
}