export class FilterConfig {
    varUserCode: string;
    dteFromDate: any;
    dteToDate: any;
    varSearchStr: string;
    varEvent: string;
    numPageValue: number;
    numCatgoryID:number
}
