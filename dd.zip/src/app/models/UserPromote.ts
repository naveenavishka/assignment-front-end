export class UserPromote {
    varClusterCode: string;
    varSBUCode: string;
    varSIteCode: string;
    varUserStatus: string;
    varUserCode: string;
    promoteType: string;
  }
  