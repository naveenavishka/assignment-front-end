export class IncidentCloseDT {
    numIncID: number;
    varActionComment: string;
    varUserCode: string;
    varActionType:string;
}