export class Site {
    numSiteID:number;
    varSBUCode: string;
    varSiteCode: string;
    varSiteName: string;
    varEmail:string;
    varEmailList:any[];
}

