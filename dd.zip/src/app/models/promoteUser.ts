export class promoteUser {
    varClusterCode?: string; // Optional properties
    varSBUCode?: string;
    varSiteCode?: string; 
    varUserStatus?: string;
    varUserCode?: string;
    promoteType?: string;
}
