export class userCatFIlter {
    varClusterCode: string;
    varSBUCode: string;
    varSIteCode: string;
    varUserStatus: string;
    varUserCode: string;
    varHeadType: string;
    varSearchStr: string;
    varFiltergroup: string;
}
