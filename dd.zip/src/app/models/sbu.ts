export class SBU {
    varClusterCode: string;
    varSBUCode: string;
    varSBUName: string;
    numSBUID: number;
    bitActive: boolean;
    varEmail?: string;
    varEmailList?: [];
}
