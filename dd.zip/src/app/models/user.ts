export class User {
    UserName?: string;
    UserCode?: string;
    WHCode?: string;
    CompCode?: string;
    WHName?: string;
    CompName?: string;
    UserToken?: string;
    TokenGenDateTime?: Date;
    UserRoleName?: string;
}
