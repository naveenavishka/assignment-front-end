export class LUser {
    userToken: string;
    authority: string;
    tokenCreateDate: Date;
    varDfltGroupCode: string;
    varDfltSBUCode: string;
    varDfltSiteCode: string;
    varEmail: string;
    varPassword: string;
    varUserCode: string;
    varUserName: string;
}
