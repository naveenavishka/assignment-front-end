export class Cluster {
    varGroupCode: string;
    varClusterCode: string;
    varClusterName: string;
    bitActive: boolean;
}
